package com.dj.abtesting;

import android.app.Application;
import android.content.Context;

import com.google.firebase.analytics.FirebaseAnalytics;

class ABTestingApp extends Application {

    private static ABTestingApp ourInstance;

    static ABTestingApp getInstance() {
        return ourInstance;
    }

    private Context context;

    private FirebaseAnalytics firebaseAnalytics;

    @Override
    public void onCreate() {
        super.onCreate();
        ourInstance =  this;
        context = getApplicationContext();
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
    }

    public Context getContext() {
        return context;
    }

    public FirebaseAnalytics getFirebaseAnalytics() {
        return firebaseAnalytics;
    }
}
